let s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
let slen = s.length
let txt1 = "Hello "
let txt2 = "World!"
document.getElementById('hello').innerHTML = txt1
document.getElementById('world').innerHTML = txt2

//functions
function myFunction()
{	
	let mv = s.slice(12, 22)
	document.getElementById('m_to_v').innerHTML = mv
	document.getElementById('slength').innerHTML = slen.toString()
}

function myFunction2()
{	
	let s_concat = txt1 + txt2
	document.getElementById('hello').innerHTML = ""
	document.getElementById('world').innerHTML = ""
	document.getElementById('concat').innerHTML = s_concat
}